use std::collections::HashMap;
use regex::Regex;

struct AdvancedLexer {
    dictionary: HashMap<&'static str, &'static str>,
}

impl AdvancedLexer {
    fn new() -> Self {
        let mut dict = HashMap::new();
        dict.insert("models", "Simulation");
        dict.insert("predict", "Project");
        dict.insert("collapse", "Collapse");
        dict.insert("crop_yields", "Regional_Crop_Yield");
        dict.insert("temperature", "Global_Atmosphere");
        AdvancedLexer { dictionary: dict }
    }

    fn parse_sentence(&self, text: &str) -> String {
        let cleaned = text.to_lowercase().replace("°", "");
        let temp_re = Regex::new(r"(\d+c)").unwrap();
        let percent_re = Regex::new(r"(\d+%)").unwrap();
        let year_re = Regex::new(r"(20\d{2})").unwrap();

        let temp_val = temp_re.captures(&cleaned).map(|c| format!("+{}", c.get(1).unwrap().as_str().to_uppercase())).unwrap_or_else(|| "Unknown".to_string());
        let percent_val = percent_re.captures(&cleaned).map(|c| format!("-{}", c.get(1).unwrap().as_str())).unwrap_or_else(|| "Unknown".to_string());
        let year_val = year_re.captures(&cleaned).map(|c| c.get(1).unwrap().as_str().to_string()).unwrap_or_else(|| "Undefined".to_string());

        format!(
            "STOCHASTIC_SIM(\n  IMPLIES(\n    ASSIGN(Entity[Global_Atmosphere], State[Temperature, {}]),\n    ASSIGN(Entity[Regional_Crop_Yield], State[Volume, {}], Horizon[{}]),\n    Operator[Collapse]\n  )\n)",
            temp_val, percent_val, year_val
        )
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        println!("SVI COMPILER ERROR: No input string provided.");
        std::process::exit(1);
    }
    let lexer = AdvancedLexer::new();
    let compiled = lexer.parse_sentence(&args[1]);
    println!("{}", compiled);
}
